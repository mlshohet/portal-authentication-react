import Login from './pages/login/login.component';

import './App.css';

function App() {
  return (
    <div className="App">
        <Login />
    </div>
  );
}

export default App;
